'use client'

import { motion } from 'framer-motion'
import { Flame } from 'lucide-react'

export default function HeroTile() {
  return (
    <motion.article
      whileHover={{ scale: 1.015 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className="relative lg:col-span-2 rounded-2xl p-6 overflow-hidden border border-white/[0.07]"
      style={{ background: 'radial-gradient(at 20% 30%, rgba(124,58,237,0.18) 0px, transparent 60%), radial-gradient(at 80% 70%, rgba(37,99,235,0.12) 0px, transparent 60%), #16161f' }}
    >
      <div className="absolute -top-16 -right-16 w-56 h-56 rounded-full bg-violet-600 opacity-[0.07] blur-3xl pointer-events-none" />
      <p className="text-slate-500 text-sm mb-1">Good morning,</p>
      <h1 className="text-3xl font-bold text-white mb-5">Welcome back, Alex 👋</h1>
      <div className="inline-flex items-center gap-2 bg-bg-hover border border-white/[0.07] rounded-full px-4 py-2">
        <Flame size={15} className="text-orange-400" />
        <span className="text-sm font-medium text-white">12 day streak</span>
        <span className="text-xs text-slate-500">— keep it up!</span>
      </div>
    </motion.article>
  )
}
