export function CourseSkeleton() {
  return (
    <div className="rounded-2xl p-5 border border-white/[0.07] bg-bg-card flex flex-col gap-4">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl skeleton" />
        <div className="flex-1 space-y-2 pt-1">
          <div className="h-3 rounded skeleton w-3/4" />
          <div className="h-3 rounded skeleton w-1/2" />
        </div>
      </div>
      <div className="mt-auto space-y-2">
        <div className="flex justify-between">
          <div className="h-2.5 rounded skeleton w-12" />
          <div className="h-2.5 rounded skeleton w-8" />
        </div>
        <div className="h-1.5 rounded-full skeleton w-full" />
      </div>
    </div>
  )
}

export function DashboardSkeletons() {
  return (
    <>
      <div className="lg:col-span-2 rounded-2xl p-6 border border-white/[0.07] bg-bg-card">
        <div className="h-3 rounded skeleton w-24 mb-3" />
        <div className="h-8 rounded skeleton w-64 mb-5" />
        <div className="h-9 rounded-full skeleton w-44" />
      </div>
      <div className="rounded-2xl p-5 border border-white/[0.07] bg-bg-card">
        <div className="h-4 rounded skeleton w-32 mb-4" />
        <div className="flex gap-1">
          {Array.from({ length: 12 }).map((_, w) => (
            <div key={w} className="flex flex-col gap-1">
              {Array.from({ length: 7 }).map((_, d) => (
                <div key={d} className="w-2.5 h-2.5 rounded-sm skeleton" />
              ))}
            </div>
          ))}
        </div>
      </div>
      {[0, 1, 2, 3].map((i) => <CourseSkeleton key={i} />)}
    </>
  )
}
