'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { LayoutDashboard, BookOpen, Trophy, Settings } from 'lucide-react'

const NAV = [
  { label: 'Home', icon: LayoutDashboard },
  { label: 'Courses', icon: BookOpen },
  { label: 'Wins', icon: Trophy },
  { label: 'Settings', icon: Settings },
]

export default function BottomNav() {
  const [active, setActive] = useState(0)
  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-bg-secondary border-t border-white/[0.07] flex z-50">
      {NAV.map((item, i) => {
        const Icon = item.icon
        const isActive = active === i
        return (
          <button key={item.label} onClick={() => setActive(i)}
            className="flex-1 flex flex-col items-center justify-center py-3 gap-1 relative">
            {isActive && (
              <motion.span layoutId="bottom-pill"
                className="absolute inset-x-2 inset-y-1 rounded-xl bg-bg-hover border border-violet-500/40"
                transition={{ type: 'spring', stiffness: 400, damping: 30 }} />
            )}
            <Icon size={19} className={`relative z-10 transition-colors ${isActive ? 'text-white' : 'text-slate-500'}`} />
            <span className={`relative z-10 text-[10px] ${isActive ? 'text-white' : 'text-slate-500'}`}>{item.label}</span>
          </button>
        )
      })}
    </nav>
  )
}
