'use client'

import { motion } from 'framer-motion'
import { Activity } from 'lucide-react'

const INTENSITY = [
  'bg-white/[0.05]',
  'bg-violet-500/25',
  'bg-violet-500/50',
  'bg-violet-500/75',
  'bg-violet-500',
]

function generateGrid() {
  return Array.from({ length: 12 }, () =>
    Array.from({ length: 7 }, () => (Math.random() > 0.4 ? Math.floor(Math.random() * 4) + 1 : 0))
  )
}

const GRID = generateGrid()

export default function ActivityTile() {
  return (
    <motion.article
      whileHover={{ scale: 1.015 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className="rounded-2xl p-5 border border-white/[0.07] bg-bg-card flex flex-col gap-4"
    >
      <header className="flex items-center gap-2">
        <Activity size={15} className="text-cyan-400" />
        <h2 className="text-sm font-semibold text-white">Learning Activity</h2>
        <span className="ml-auto text-xs text-slate-600">Last 12 weeks</span>
      </header>
      <div className="flex gap-1">
        {GRID.map((week, wi) => (
          <div key={wi} className="flex flex-col gap-1">
            {week.map((level, di) => (
              <motion.div
                key={di}
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: (wi * 7 + di) * 0.004 }}
                className={`w-2.5 h-2.5 rounded-sm ${INTENSITY[level]}`}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="flex items-center gap-1.5 text-xs text-slate-600 mt-auto">
        <span>Less</span>
        {INTENSITY.map((cls, i) => <div key={i} className={`w-2.5 h-2.5 rounded-sm ${cls}`} />)}
        <span>More</span>
      </div>
    </motion.article>
  )
}
