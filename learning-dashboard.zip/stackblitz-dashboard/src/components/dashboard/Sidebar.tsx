'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { LayoutDashboard, BookOpen, Trophy, Settings, ChevronLeft, Zap } from 'lucide-react'
import clsx from 'clsx'

const NAV = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Courses', icon: BookOpen },
  { label: 'Achievements', icon: Trophy },
  { label: 'Settings', icon: Settings },
]

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)
  const [active, setActive] = useState(0)

  return (
    <motion.nav
      animate={{ width: collapsed ? 64 : 220 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="hidden md:flex flex-col h-screen bg-bg-secondary border-r border-white/[0.07] shrink-0 overflow-hidden"
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-white/[0.07]">
        <div className="w-8 h-8 rounded-lg bg-violet-600 flex items-center justify-center shrink-0"
          style={{ boxShadow: '0 0 18px rgba(124,58,237,0.5)' }}>
          <Zap size={15} className="text-white" />
        </div>
        <AnimatePresence>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -6 }}
              transition={{ duration: 0.15 }}
              className="text-sm font-bold text-white whitespace-nowrap tracking-wide"
            >
              LearnFlow
            </motion.span>
          )}
        </AnimatePresence>
      </div>

      {/* Nav */}
      <ul className="flex flex-col gap-1 p-2 flex-1 mt-2">
        {NAV.map((item, i) => {
          const Icon = item.icon
          const isActive = active === i
          return (
            <li key={item.label}>
              <button
                onClick={() => setActive(i)}
                className={clsx(
                  'relative w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors duration-150',
                  isActive ? 'text-white' : 'text-slate-500 hover:text-slate-300'
                )}
              >
                {isActive && (
                  <motion.span
                    layoutId="sidebar-pill"
                    className="absolute inset-0 rounded-xl bg-bg-hover border border-violet-500/40"
                    style={{ boxShadow: '0 0 14px rgba(124,58,237,0.18)' }}
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}
                <Icon size={17} className="relative z-10 shrink-0" />
                <AnimatePresence>
                  {!collapsed && (
                    <motion.span
                      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      className="relative z-10 text-sm whitespace-nowrap"
                    >
                      {item.label}
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
            </li>
          )
        })}
      </ul>

      {/* Collapse */}
      <div className="p-2 border-t border-white/[0.07]">
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="w-full flex items-center justify-center p-2 rounded-xl text-slate-500 hover:text-white hover:bg-bg-hover transition-colors"
        >
          <motion.div animate={{ rotate: collapsed ? 180 : 0 }} transition={{ type: 'spring', stiffness: 300, damping: 25 }}>
            <ChevronLeft size={17} />
          </motion.div>
        </button>
      </div>
    </motion.nav>
  )
}
