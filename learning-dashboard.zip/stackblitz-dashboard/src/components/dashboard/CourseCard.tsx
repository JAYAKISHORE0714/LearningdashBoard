'use client'

import { motion } from 'framer-motion'
import type { Course } from '@/types'
import DynamicIcon from '@/components/ui/DynamicIcon'
import ProgressBar from '@/components/ui/ProgressBar'

const MESHES = [
  'radial-gradient(at 20% 30%, rgba(124,58,237,0.14) 0px, transparent 60%), radial-gradient(at 80% 80%, rgba(37,99,235,0.09) 0px, transparent 60%), #16161f',
  'radial-gradient(at 70% 20%, rgba(37,99,235,0.14) 0px, transparent 60%), radial-gradient(at 20% 80%, rgba(6,182,212,0.09) 0px, transparent 60%), #16161f',
  'radial-gradient(at 50% 10%, rgba(6,182,212,0.14) 0px, transparent 60%), radial-gradient(at 80% 90%, rgba(124,58,237,0.09) 0px, transparent 60%), #16161f',
  'radial-gradient(at 10% 80%, rgba(124,58,237,0.14) 0px, transparent 60%), radial-gradient(at 90% 20%, rgba(16,185,129,0.09) 0px, transparent 60%), #16161f',
]

export default function CourseCard({ course, index }: { course: Course; index: number }) {
  return (
    <motion.article
      whileHover={{ scale: 1.02, borderColor: 'rgba(124,58,237,0.55)' }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
      className="relative rounded-2xl p-5 overflow-hidden border border-white/[0.07] flex flex-col gap-4"
      style={{
        background: MESHES[index % MESHES.length],
        boxShadow: '0 4px 24px rgba(0,0,0,0.35)',
      }}
    >
      {/* grain texture */}
      <div className="absolute inset-0 opacity-[0.025] pointer-events-none"
        style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")", backgroundSize: '128px' }} />

      <div className="relative z-10 flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-white/[0.05] border border-white/[0.07] flex items-center justify-center shrink-0">
          <DynamicIcon name={course.icon_name} size={18} className="text-cyan-400" />
        </div>
        <h3 className="text-sm font-semibold text-white leading-snug pt-1">{course.title}</h3>
      </div>

      <div className="relative z-10 mt-auto">
        <div className="flex justify-between mb-2">
          <span className="text-xs text-slate-500">Progress</span>
          <span className="text-xs font-medium text-slate-300">{course.progress}%</span>
        </div>
        <ProgressBar value={course.progress} />
      </div>
    </motion.article>
  )
}
