import { getCourses } from '@/lib/supabase'
import BentoGrid from './BentoGrid'

export default async function CoursesSection() {
  const courses = await getCourses()
  return <BentoGrid courses={courses} />
}
