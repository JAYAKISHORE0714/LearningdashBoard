'use client'

import { motion } from 'framer-motion'

export default function ProgressBar({ value }: { value: number }) {
  return (
    <div className="h-1.5 w-full rounded-full bg-white/[0.08] overflow-hidden">
      <motion.div
        className="h-full rounded-full"
        style={{ background: 'linear-gradient(90deg,#7c3aed,#2563eb)', boxShadow: '0 0 8px rgba(124,58,237,0.55)' }}
        initial={{ width: '0%' }}
        animate={{ width: `${value}%` }}
        transition={{ duration: 1.2, ease: 'easeOut', delay: 0.4 }}
      />
    </div>
  )
}
