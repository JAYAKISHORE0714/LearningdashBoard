import * as Icons from 'lucide-react'
import type { LucideProps } from 'lucide-react'

export default function DynamicIcon({ name, ...props }: { name: string } & LucideProps) {
  const Icon = (Icons as Record<string, React.ComponentType<LucideProps>>)[name]
  const Fallback = Icons.BookOpen
  return Icon ? <Icon {...props} /> : <Fallback {...props} />
}
