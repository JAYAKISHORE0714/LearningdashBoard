import { createClient } from '@supabase/supabase-js'
import type { Course } from '@/types'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

const MOCK_COURSES: Course[] = [
  { id: '1', title: 'Advanced React Patterns', progress: 75, icon_name: 'Code2', created_at: new Date().toISOString() },
  { id: '2', title: 'TypeScript Deep Dive', progress: 42, icon_name: 'FileCode', created_at: new Date().toISOString() },
  { id: '3', title: 'Next.js App Router', progress: 88, icon_name: 'Layers', created_at: new Date().toISOString() },
  { id: '4', title: 'Framer Motion Mastery', progress: 20, icon_name: 'PlayCircle', created_at: new Date().toISOString() },
]

export async function getCourses(): Promise<Course[]> {
  const isPlaceholder =
    !supabaseUrl ||
    supabaseUrl.includes('placeholder') ||
    !supabaseAnonKey ||
    supabaseAnonKey.includes('placeholder')

  if (isPlaceholder) {
    await new Promise((r) => setTimeout(r, 800))
    return MOCK_COURSES
  }

  try {
    const { data, error } = await supabase
      .from('courses')
      .select('*')
      .order('created_at', { ascending: true })

    if (error) throw error
    return data ?? MOCK_COURSES
  } catch (err) {
    console.error('Supabase error, using mock data:', err)
    return MOCK_COURSES
  }
}
