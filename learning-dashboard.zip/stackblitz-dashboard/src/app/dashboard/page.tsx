import { Suspense } from 'react'
import Sidebar from '@/components/dashboard/Sidebar'
import BottomNav from '@/components/dashboard/BottomNav'
import CoursesSection from '@/components/dashboard/CoursesSection'
import { DashboardSkeletons } from '@/components/dashboard/Skeletons'

export default function DashboardPage() {
  return (
    <div className="flex min-h-screen bg-bg-primary">
      <Sidebar />
      <main className="flex-1 overflow-y-auto pb-20 md:pb-0">
        <Suspense
          fallback={
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4 md:p-6">
              <DashboardSkeletons />
            </div>
          }
        >
          <CoursesSection />
        </Suspense>
      </main>
      <BottomNav />
    </div>
  )
}
