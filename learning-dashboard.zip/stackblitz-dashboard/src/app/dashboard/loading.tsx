import { DashboardSkeletons } from '@/components/dashboard/Skeletons'

export default function Loading() {
  return (
    <div className="flex min-h-screen bg-bg-primary">
      <div className="w-[220px] hidden md:block border-r border-white/[0.07] bg-bg-secondary" />
      <main className="flex-1">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4 md:p-6">
          <DashboardSkeletons />
        </div>
      </main>
    </div>
  )
}
